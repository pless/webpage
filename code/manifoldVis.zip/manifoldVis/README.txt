This set of matlab files is intended to makes tools for the
interactive display of 2 dimensional image manifolds.

There are 5 files here.  The main functions are:

manVISGUI.m: which is a standalone m-file that takes as input a set of
             images and their 2D coordinates, and creates an
             interactive matlab figure which shows the image whose 2D
             coordinate is closest to the current mouse position

manVISGUICallback.m: A helper function for manVISGUI, that is called
                     as the mouse moves and implements the interactivity.

manVisWebGUI.m: A function which outputs HTML/javascript code to
                implement the same interactive visualization.

manVisDemo.m:  A demo program to highlight how these functions can be used.

manVisMakeSampleData.m: Supports the demo program by making one, very
                        boring, image manifold.
