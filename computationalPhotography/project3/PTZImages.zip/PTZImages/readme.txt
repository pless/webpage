This contains 9 images captured from a live PTZ webcam:

http://121.93.137.233/viewer/live/index.html?lang=en

If you click around the controls, you can gain control of the webcam
and pan and tilt and zoom it.

